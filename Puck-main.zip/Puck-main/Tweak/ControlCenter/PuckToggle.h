#import <UIKit/UIKit.h>
#import <ControlCenterUIKit/CCUIToggleModule.h>

@interface PuckToggle : CCUIToggleModule {
  BOOL _selected;
}
@end
