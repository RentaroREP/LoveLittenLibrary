#import <libactivator/libactivator.h>

#define PuckActivatorShutdown @"love.litten.puck/Shutdown"

@interface PuckShutdownListener : NSObject <LAListener>
@end