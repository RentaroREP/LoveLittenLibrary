#import <libactivator/libactivator.h>

#define PuckActivatorWake @"love.litten.puck/Wake"

@interface PuckWakeListener : NSObject <LAListener>
@end