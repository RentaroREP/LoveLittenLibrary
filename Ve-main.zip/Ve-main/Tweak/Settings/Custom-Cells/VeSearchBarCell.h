#import <UIKit/UIKit.h>
#import <Preferences/PSSpecifier.h>

@interface VeSearchBarCell : PSTableCell
@property(nonatomic, retain)UISearchBar* searchBar;
@end