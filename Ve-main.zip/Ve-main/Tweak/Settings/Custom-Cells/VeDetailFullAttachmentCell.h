#import <UIKit/UIKit.h>
#import <Preferences/PSSpecifier.h>

@interface VeDetailFullAttachmentCell : PSTableCell
@property(nonatomic, retain)UIImageView* attachmentImageView;
@end