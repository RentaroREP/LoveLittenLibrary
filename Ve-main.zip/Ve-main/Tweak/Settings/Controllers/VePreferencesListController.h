#import <Preferences/PSListController.h>

@interface VePreferencesListController : PSListController
@property(nonatomic, retain)UINavigationController* preferencesRootViewController;
@end