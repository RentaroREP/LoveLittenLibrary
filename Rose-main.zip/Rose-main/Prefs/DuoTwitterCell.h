#import "KRLinkCell.h"

@interface DuoTwitterCell : KRTableCell

@end