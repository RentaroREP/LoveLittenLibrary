#import "KRLinkCell.h"

@interface KRTwitterCell : KRLinkCell

@end