#import "Preferences/PSTableCell.h"

@interface KRTableCell : PSTableCell
@end